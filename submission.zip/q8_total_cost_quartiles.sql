NULL|DUMO|1615.9
NULL|OCEA|3460.2
NULL|ANTO|7515.35
NULL|QUEE|30226.1
Trail's Head Gourmet Provisioners|TRAIH|3874502.02
Blondesddsl père et fils|BLONP|3879728.69
Around the Horn|AROUT|4395636.28
Hungry Owl All-Night Grocers|HUNGO|4431457.1
Bon app|BONAP|4485708.49
Bólido Comidas preparadas|BOLID|4520121.88
Galería del gastrónomo|GALED|4533089.9
FISSA Fabrica Inter. Salchichas S.A.|FISSA|4554591.02
Maison Dewey|MAISD|4555931.37
Cactus Comidas para llevar|CACTU|4559046.87
Spécialités du monde|SPECD|4571764.89
Magazzini Alimentari Riuniti|MAGAA|4572382.35
Toms Spezialitäten|TOMSP|4628403.36
Split Rail Beer & Ale|SPLIR|4641383.53
Santé Gourmet|SANTG|4647668.15
Morgenstern Gesundkost|MORGK|4676234.2
White Clover Markets|WHITC|4681531.74
La corne d'abondance|LACOR|4724494.22
Victuailles en stock|VICTE|4726476.33
Lonesome Pine Restaurant|LONEP|4735780.66
Bottom-Dollar Markets|BOTTM|4738375.12
Tortuga Restaurante|TORTU|4742734.16
Die Wandernde Kuh|WANDK|4761623.38
Piccolo und mehr|PICCO|4785193.89
Centro comercial Moctezuma|CENTC|4793276.96
Que Delícia|QUEDE|4797474.59
Folk och fä HB|FOLKO|4799443.06
Let's Stop N Shop|LETSS|4819493.19
Rattlesnake Canyon Grocery|RATTC|4821545.59
Seven Seas Imports|SEVES|4833578.14
Franchi S.p.A.|FRANS|4859123.65
Comércio Mineiro|COMMI|4879867.23
Du monde entier|DUMON|4886320.94
Great Lakes Food Market|GREAL|4895045.61
HILARION-Abastos|HILAA|4896260.33
B's Beverages|BSBEV|4908283.21
Island Trading|ISLAT|4949660.03
Paris spécialités|PARIS|4969031.51
Blauer See Delikatessen|BLAUS|4969200.63
Königlich Essen|KOENE|5001550.75
Reggiani Caseifici|REGGC|5004808.26
Frankenversand|FRANK|5009670.58
The Cracker Box|THECR|5013905.09
Rancho grande|RANCH|5020919.85
France restauration|FRANR|5040458.77
Princesa Isabel Vinhos|PRINI|5055537.12
North/South|NORTS|5069898.6
Laughing Bacchus Wine Cellars|LAUGB|5086312.15
Godos Cocina Típica|GODOS|5094487.44
Richter Supermarkt|RICSU|5095005.88
Suprêmes délices|SUPRD|5112584.97
Wilman Kala|WILMK|5116910.87
Pericles Comidas clásicas|PERIC|5138374.12
Consolidated Holdings|CONSH|5153756.53
Hanari Carnes|HANAR|5163871.48
Ernst Handel|ERNSH|5166312.67
Familia Arquibaldo|FAMIA|5176903.0
Wolski  Zajazd|WOLZA|5196525.31
Ana Trujillo Emparedados y helados|ANATR|5208686.42
Océano Atlántico Ltda.|OCEAN|5223787.97
Chop-suey Chinese|CHOPS|5227683.35
Ottilies Käseladen|OTTIK|5231226.35
LINO-Delicateses|LINOD|5232558.59
Wartian Herkku|WARTH|5242473.68
Eastern Connection|EASTC|5245694.06
Antonio Moreno Taquería|ANTON|5262405.09
Romero y tomillo|ROMEY|5265845.64
Mère Paillarde|MEREP|5272657.05
Lehmanns Marktstand|LEHMS|5279437.88
Wellington Importadora|WELLI|5280777.78
Vaffeljernet|VAFFE|5284250.4
QUICK-Stop|QUICK|5304202.32
Alfreds Futterkiste|ALFKI|5317516.28
Simons bistro|SIMOB|5322857.47
Furia Bacalhau e Frutos do Mar|FURIB|5327297.29
Drachenblut Delikatessen|DRACD|5364791.91
LILA-Supermercado|LILAS|5365836.48
Queen Cozinha|QUEEN|5388220.57
Save-a-lot Markets|SAVEA|5406166.19
Hungry Coyote Import Store|HUNGC|5410736.54
Gourmet Lanchonetes|GOURL|5419227.12
Folies gourmandes|FOLIG|5420655.87
Tradição Hipermercados|TRADH|5539617.05
Old World Delicatessen|OLDWO|5564105.62
Vins et alcools Chevalier|VINET|5584238.62
Lazy K Kountry Store|LAZYK|5585821.39
The Big Cheese|THEBI|5623248.51
Berglunds snabbköp|BERGS|5677655.08
Ricardo Adocicados|RICAR|5816861.47
GROSELLA-Restaurante|GROSR|5905508.55
La maison d'Asie|LAMAI|6091565.09
